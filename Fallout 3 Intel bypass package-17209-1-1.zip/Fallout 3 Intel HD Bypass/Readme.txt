the D3D9.dll file should go into your fallout 3 file. it will trick the game into thinking you have an nvidia geforce 7000.

the FALLOUT.ini folder included should go in the folder: libraries > documents > my games > fallout3 > .it adds a line to the code to basically just tell the game to take it easy.


Credits:
i beleive in giving full credit where it is due.

D3D9 file: ryanshedy on the techgage forums http://forums.techgage.com/showthread.php?t=5052

Fallout.ini: put together by me, although i did use a page on the oblivion forums